package com.demoXMLConfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestProduct {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("config2.xml");

		// Product product = new Product();
		Product product = (Product) context.getBean("product1");
		
		Product product1 = (Product) context.getBean("product2");

		System.out.println(product.toString());
		
		System.out.println(product1.toString());

	}

}
