package com.demoJavaConfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestProduct {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(ProductConfiguration.class);

		Product product = (Product) context.getBean("product1");
		product.setProductID(101);
		product.setProductName("HP Victus");
		product.setProductPrice(82000);
	

		System.out.println(product.toString());
		
		System.out.println("------------------------------------------------------------------------");
			
		Product product1 = (Product) context.getBean("product1");
		product.setProductID(102);
		product.setProductName("Dell Laptop");
		product.setProductPrice(98000);

		System.out.println(product1.toString());

		System.out.println("------------------------------------------------------------------------");
		Product product2 = (Product) context.getBean("product1");
		product.setProductID(103);
		product.setProductName("Asus Laptop");
		product.setProductPrice(73500);

		System.out.println(product2.toString());
	}

}
