package com.demoJavaConfiguration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProductConfiguration 
{
	
	@Bean(name="product1")
	public Product getCustomer1()
	{
		return new Product();
	}
	
	@Bean(name="product2")
	public Product getCustomer2()
	{
		return new Product();
	}
	
	@Bean(name="product3")
	public Product getCustomer3()
	{
		return new Product();
	}

}