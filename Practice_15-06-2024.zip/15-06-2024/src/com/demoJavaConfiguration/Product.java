package com.demoJavaConfiguration;

public class Product {

	// fields
	private int productID;
	private String productName;
	private int productPrice;
	

	// constructors
	public Product() {
		// TODO Auto-generated constructor stub
	}


	public Product(int productID, String productName, int productPrice) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.productPrice = productPrice;
	}


	public void setProductID(int productID) {
		this.productID = productID;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}


	@Override
	public String toString() {
		return "Product [productID=" + productID + ", productName=" + productName + ", productPrice=" + productPrice
				+ "]";
	}

	


}
