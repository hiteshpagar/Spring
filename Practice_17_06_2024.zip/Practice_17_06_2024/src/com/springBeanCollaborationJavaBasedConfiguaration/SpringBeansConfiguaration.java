package com.springBeanCollaborationJavaBasedConfiguaration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringBeansConfiguaration {

	
	@Bean(name="employee10")
	public Employee getEmployeeBean()
	{
		return new Employee();
	}
	
	@Bean(name="department10")
	public Department getDepartmentBean()
	{
		return new Department();
	}
	
}
