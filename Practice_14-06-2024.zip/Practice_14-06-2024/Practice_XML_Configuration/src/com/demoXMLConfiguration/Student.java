package com.demoXMLConfiguration;

public class Student {

	// fields
	private int studentRollNo;
	private String studentName;
	private int studentAge;
	private String studentGender;

	// constructors
	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int studentRollNo, String studentName, int studentAge, String studentGender) {
		super();
		this.studentRollNo = studentRollNo;
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.studentGender = studentGender;
	}

	@Override
	public String toString() {
		return "Student [studentRollNo=" + studentRollNo + ", studentName=" + studentName + ", studentAge=" + studentAge
				+ ", studentGender=" + studentGender + "]";
	}

}
