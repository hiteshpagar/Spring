package com.demoJavaConfiguration;

public class Customer {

	// fields
	private int customerID;
	private String customerName;
	private String customerLocation;
	private int customerAge;
	private String customerGender;

	// constructors
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(int customerID, String customerName, String customerLocation, int customerAge,
			String customerGender) {
		super();
		this.customerID = customerID;
		this.customerName = customerName;
		this.customerLocation = customerLocation;
		this.customerAge = customerAge;
		this.customerGender = customerGender;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setCustomerLocation(String customerLocation) {
		this.customerLocation = customerLocation;
	}

	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}

	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", customerName=" + customerName + ", customerLocation="
				+ customerLocation + ", customerAge=" + customerAge + ", customerGender=" + customerGender + "]";
	}

}
