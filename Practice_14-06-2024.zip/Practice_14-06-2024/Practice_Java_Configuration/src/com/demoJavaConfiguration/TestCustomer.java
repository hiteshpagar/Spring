package com.demoJavaConfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestCustomer {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(CustomerConfiguration.class);

		Customer customer = (Customer) context.getBean("customer1");
		customer.setCustomerID(101);
		customer.setCustomerName("Hitesh");
		customer.setCustomerLocation("Pune");
		customer.setCustomerAge(21);
		customer.setCustomerGender("Male");

		System.out.println(customer.toString());
		
		System.out.println("------------------------------------------------------------------------");
			
		Customer customer1 = (Customer) context.getBean("customer2");
		customer1.setCustomerID(102);
		customer1.setCustomerName("Rahul");
		customer1.setCustomerLocation("Mumbai");
		customer1.setCustomerAge(25);
		customer1.setCustomerGender("Male");

		System.out.println(customer1.toString());

		System.out.println("------------------------------------------------------------------------");
		
		Customer customer2 = (Customer) context.getBean("customer3");
		customer2.setCustomerID(103);
		customer2.setCustomerName("Rushikesh");
		customer2.setCustomerLocation("Delhi");
		customer2.setCustomerAge(23);
		customer2.setCustomerGender("Male");

		System.out.println(customer2.toString());
	}

}
