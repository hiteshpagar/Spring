package com.demoJavaConfiguration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CustomerConfiguration 
{
	
	@Bean(name="customer1")
	public Customer getCustomer1()
	{
		return new Customer();
	}
	
	@Bean(name="customer2")
	public Customer getCustomer2()
	{
		return new Customer();
	}
	
	@Bean(name="customer3")
	public Customer getCustomer3()
	{
		return new Customer();
	}

}